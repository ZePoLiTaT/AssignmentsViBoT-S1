im1 = imread('wolff/results/im45.png');
imask = imread('wolff/results/mask.png');
imshow(im1+imask);