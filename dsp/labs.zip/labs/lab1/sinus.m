function [ signal ] = sinus( f, N, nT )
%UNTITLED7 Summary of this function goes here
%   Detailed explanation goes here

n = [1:];
signal = sin(2*pi*f*n

end

