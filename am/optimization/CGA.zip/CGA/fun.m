function[y]=fun(x);
y=sin(10*x)^2/(1+x);
return