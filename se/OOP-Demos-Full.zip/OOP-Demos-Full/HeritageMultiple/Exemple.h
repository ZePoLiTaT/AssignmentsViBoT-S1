#ifndef EXEMPLE_H
#define EXEMPLE_H

#include <iostream>
using namespace std;


//--------------------------------
//
// Premier exemple : A est classe de base, B et C dérivent de A, D dérive à la fois de B et de C...
// on va passer par l'opérateur de résolution de portée :: pour lever l'ambiguite
//
//--------------------------------


class A1 {

public :
    int m_A;
    void f () {cout <<" A1::f()"<<endl;}
    A1 ( ) {cout <<" A1 ()"<<endl;}
    ~A1 ( ) {cout <<"~A1 ()"<<endl;}
};

class B1 : public A1 {
public :
    int m_B;

    B1 ( ) {cout <<" B1 ()"<<endl;}
    ~B1 ( ) {cout <<"~B1 ()"<<endl;}
};

class C1 : public  A1{
public :
    int m_C;

    C1 ( ) {cout <<" C1 ()"<<endl;}
    ~C1 ( ) {cout <<"~C1 ()"<<endl;}
};

class D1 : public B1, public C1 {
public :
    int m_D;

    D1 ( ) {cout <<" D1 ()"<<endl;}
    ~D1 ( ) {cout <<"~D1 ()"<<endl;}
};

void Exemple1();

//--------------------------------
//
// Second exemple . idem mais avec heritage multiple virtuel pour lever l'ambiguité
//
//--------------------------------


class A2 {

public :
    int m_A;
    void f () {cout <<" A2::f()"<<endl;}
    A2 ( ) {cout <<" A2 ()"<<endl;}
    ~A2 ( ) {cout <<"~A2 ()"<<endl;}
};

class B2 : virtual public A2 {
public :
    int m_B;

    B2 ( ) {cout <<" B2 ()"<<endl;}
    ~B2 ( ) {cout <<"~B2 ()"<<endl;}
};

class C2 : virtual public  A2{
public :
    int m_C;

    C2 ( ) {cout <<" C2 ()"<<endl;}
    ~C2 ( ) {cout <<"~C2 ()"<<endl;}
};

class D2 : public B2, public  C2 {
public :
    int m_D;

    D2 ( ) {cout <<" D2 ()"<<endl;}
    ~D2 ( ) {cout <<"~D2 ()"<<endl;}
};

void Exemple2();



#endif // EXEMPLE_H
