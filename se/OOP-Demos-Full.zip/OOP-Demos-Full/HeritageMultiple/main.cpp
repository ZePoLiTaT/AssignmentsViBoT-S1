#include <QCoreApplication>
#include "Exemple.h"

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    //un premier exemple avec un héritage multiple qui va crééer une ambiguité avec l'appel d'une fonction f commune
    // autre point à remarquer : l'ordre et le nombre d'appels des constructeurs / destructeurs...
    Exemple1 ();

    // un second exemple avec un héritage multiple. L'ambiguité va être levée grâce à des héritages virtuels
    // autre point à remarquer : l'ordre et le nombre d'appels des constructeurs / destructeurs...
    Exemple2 ();

    
    return app.exec();
}
