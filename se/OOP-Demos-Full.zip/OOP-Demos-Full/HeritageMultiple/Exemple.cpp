#include "Exemple.h"
#include <iostream>
using namespace std;

void Exemple1()
{
    system ("cls");
    cout <<"\t\t EXEMPLE 1 avec classes A1, B1, C1 et D1"<<endl<<endl;
    cout <<"Creation d'une instance de classe A1"<<endl;
    A1 a;

    cout <<"Creation d'une instance de classe B1"<<endl;
    B1 b;

    cout <<"Creation d'une instance de classe C1"<<endl;
    C1 c;

    cout <<"Creation d'une instance de classe D1. A VOIR ICI : DOUBLONS DES APPELS CSTR"<<endl;
    D1 d;

    //appel de la fonction f()
    cout <<"a.f() => ";a.f(); //appel direct : OK
    cout <<"b.f() => ";b.f(); //appel direct car f héritée de A2 en B2 : OK
    cout <<"c.f() => ";c.f(); //appel direct car f héritée de A2 en C2 : OK

    //TEST : otez les commentaires suivants pour avoir une erreur de compilation
    // d.f(); // Erreur : ambiguité. Le compilateur ne sait pas quelle fonction f utiliser

    //solution : explicitement spécifier quelle fonction f on veut utiliser
    cout <<endl<< "resolution ambiguite..."<<endl;
    cout <<"d.B1::f() => "; d.B1::f();
    cout <<"d.C1::f() => "; d.C1::f();
    system("pause");
}


void Exemple2()
{
    system ("cls");
    cout <<"\t\t EXEMPLE 2 avec classes A2, B2, C2 et D2"<<endl<<endl;
    cout <<"Creation d'une instance de classe A2"<<endl;
    A2 a;

    cout <<"Creation d'une instance de classe B2"<<endl;
    B2 b;

    cout <<"Creation d'une instance de classe C2"<<endl;
    C2 c;

    cout <<"Creation d'une instance de classe D2. A VOIR : PAS DE DOUBLON!"<<endl;
    D2 d;

    //appel de la fonction f()
    cout <<"a.f() => ";a.f(); //appel direct : OK
    cout <<"b.f() => ";b.f(); //appel direct car f redéfinie dans B : OK
    cout <<"c.f() => ";c.f(); //appel direct car f redéfinie dans C : OK

    cout <<"d.f() => ";d.f(); // Ici, pas de problème : comme on a fait un héritage virtuel, le compilateur sait quelle fonction utiliser (A2 :: f() ici)
    system("pause");
}
