#include <QCoreApplication>
#include "TemplateExample1.h"
#include <cmath>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    

    Tableau1 <int> Tabint;

    cout <<"PREMIER EXEMPLE AVEC TABLEAU A TAILLE FIXE = 10"<<endl;
    for (int i=0; i<10; i++) Tabint[i] = i*i*i;

    cout << Tabint <<endl;
    cout << "la valeur 65 est en position "<<Tabint.Find(65)<<endl;
    cout << "la valeur 729 est en position "<<Tabint.Find(729)<<endl;

    cout <<endl;
    Tableau1 <char> Tabchar;

    for (int i=0; i<10; i++) Tabchar[i] = 'f' + i;

    cout << Tabchar <<endl;

    cout << "la lettre k est en position "<<Tabchar.Find('k')<<endl;
    cout << "la lettre z est en position "<<Tabchar.Find('z')<<endl;

    system("pause");
    system ("cls");

    cout <<"DEUXIEME EXEMPLE AVEC TABLEAU A TAILLE VARIABLE"<<endl;
    const int n = 20;
    Tableau2  < int, n> MonSuperTableau;
    for (int i=0; i<n; i++) MonSuperTableau[i] = pow (2,i);
    cout << MonSuperTableau << endl;

    system("pause");
    system ("cls");

    cout <<"TROISIEME EXEMPLE POUR ILLUSTRER TYPEDEF"<<endl;

    vector2i toto; for (int i =0; i< toto.size(); i++) toto[i] = 3*i + 4; cout <<"toto="<<toto<<endl;
    vector3f titi; for (int i =0; i< titi.size(); i++) titi[i] = 3.1*i + 4.05; cout <<"titi="<<titi<<endl;
    vector4d tutu; for (int i =0; i< tutu.size(); i++) tutu[i] = 0.1*i + 4.0005; cout <<"tutu="<<tutu<<endl;









    return a.exec();
}


