#ifndef TEMPLATEEXAMPLE1_H
#define TEMPLATEEXAMPLE1_H

#include <cassert>
#include <iostream>
using namespace std;


//--------------------------------------------------------------------------------------------------
//
// Spécialisation de classe template avec un paramètre typé : on fait varier la nature du paramètre
//
//--------------------------------------------------------------------------------------------------


template <typename T>
class Tableau1
{
private:
     T m_data[10];      // allocation statique d'un tableau de 10 éléments de type T

public:

    Tableau1 ( ) { }     // constructeur par défaut
    ~Tableau1 ( ) { }    // destructeur

    //surcharge de l'opérateur [] en lecture et en écriture

    //lecture seule. Attention aux const!!
    const T& operator [ ] (unsigned int i) const;

    //écriture seule, plus facile à comprendre
    T& operator [ ] (unsigned int i);

    //trouver la position d'un élément dans le tableau
    int Find ( const T& val) ;
};


template <typename T>
const T& Tableau1 <T> :: operator [ ] (unsigned int i) const
{
    assert (i>=0 && i<10);
    return m_data[i];
}

//écriture seule, plus facile à comprendre
template <typename T>
T& Tableau1 <T> :: operator [ ] (unsigned int i)
{
    assert (i>=0 && i<10);
    return m_data[i];
}

//trouver la position d'un élément dans le tableau
template <typename T>
int Tableau1 <T> :: Find ( const T& val) {
    for (int i=0; i<10; i++)
        if (m_data[i]==val)
            return i;
    return -1;
}


//surcharge de l'opérateur << . Même principe qu'auparavant sauf que c'est désormais une fonction générique
template <typename T>
ostream & operator << (ostream & flot, const Tableau1<T> & MonTab) {

    for (int i=0; i<10; i++)
        flot << MonTab[i]<<", ";
  return flot;
}


//--------------------------------------------------------------------------------------------------
// Spécialisation de classe template avec, en plus, un paramètre non typé :
// on fait toujours varier la nature du paramètre mais en plus on va ajuster la taille du tableau
//--------------------------------------------------------------------------------------------------

template <typename T, int n>
class Tableau2
{
private:
     T m_data[n];      // allocation statique d'un tableau de n éléments de type T

public:

    Tableau2 ( ) { }     // constructeur par défaut
    ~Tableau2 ( ) { }    // destructeur

    //une petite fonction bien pratique pour récupérer la valeur de n
    inline const int size() {return n;}


    //surcharge de l'opérateur [] en lecture et en écriture

    //lecture seule. Attention aux const!!
    const T& operator [ ] (unsigned int i) const;

    //écriture seule, plus facile à comprendre
    T& operator [ ] (unsigned int i);

    //trouver la position d'un élément dans le tableau
    int Find ( const T& val) ;
};


template <typename T, int n>
const T& Tableau2 <T,n> :: operator [ ] (unsigned int i) const
{
    assert (i>=0 && i<n); // n et non plus 10
    return m_data[i];
}

//écriture seule, plus facile à comprendre
template <typename T, int n>
T& Tableau2 <T,n> :: operator [ ] (unsigned int i)
{
    assert (i>=0 && i<n); // n et non plus 10
    return m_data[i];
}

//trouver la position d'un élément dans le tableau
template <typename T, int n>
int Tableau2 <T,n> :: Find ( const T& val) {
    for (int i=0; i<n; i++) // n et non plus 10
        if (m_data[i]==val)
            return i;
    return -1;
}

//surcharge de l'opérateur << . Même principe qu'auparavant sauf que c'est désormais une fonction générique
template <typename T, int n>
ostream & operator << (ostream & flot, const Tableau2<T,n> & MonTab) {

    for (int i=0; i<n; i++) // n et non plus 10
        flot << MonTab[i]<<", ";
  return flot;
}

//------------------------------------
//
// Exemple de "bonne" utilisation du mot clef typedef pour simplifier les notations
//
//------------------------------------

typedef Tableau2 <int, 2> vector2i;
typedef Tableau2 <int, 3> vector3i;
typedef Tableau2 <int, 4> vector4i;

typedef Tableau2 <float, 2> vector2f;
typedef Tableau2 <float, 3> vector3f;
typedef Tableau2 <float, 4> vector4f;

typedef Tableau2 <double, 2> vector2d;
typedef Tableau2 <double, 3> vector3d;
typedef Tableau2 <double, 4> vector4d;







#endif // TEMPLATEEXAMPLE1_H

