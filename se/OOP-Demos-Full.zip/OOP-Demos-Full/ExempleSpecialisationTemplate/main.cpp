#include <QCoreApplication>
#include "ExempleSpecialisationTemplate.h"
#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //premier exemple en utilisant le type int
    mycontainer<int> myint (7);
    cout << myint.increase() << endl;

    // ligne suivante --> ERREUR car uppercase() n'existe pas pour le type int
    //cout << myint.uppercase() << endl;


    //second exemple avec le type char
    mycontainer<char> mychar ('j');

    //ligne suivante --> ERREUR car increase() n'existe pas pour le type char
    //cout << mychar.increase() << endl;

    cout << mychar.uppercase() << endl;
    return a.exec();
}
