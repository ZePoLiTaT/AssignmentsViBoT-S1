#ifndef EXEMPLESPECIALISATIONTEMPLATE_H
#define EXEMPLESPECIALISATIONTEMPLATE_H


#include <iostream>
using namespace std;

//--------------------------------------------------------------------------------------------------
//
// Spécialisation de fonction template : un comportement différent selon la nature du type générique
//
//--------------------------------------------------------------------------------------------------

// Version générique
template <typename T>
void QuiSuisJe( const T & x )
{
    cout << "Je ne sais pas" << endl;
}

// Spécialisation pour les int
template < >
void QuiSuisJe<int>( const int & x )
{
    cout << "Je suis un int" << endl;
}

// Spécialisation pour ma classe
template <>
void QuiSuisJe<MaClasse>( const MaClasse & x )
{
    cout << "Je suis un MaClasse" << endl;
}

// Test
MaClasse Test1;
int Test2;
float Test3;

QuiSuisJe( Test1 ); // "Je suis un MaClasse"
QuiSuisJe( Test2 ); // "Je suis un int"
QuiSuisJe( Test3 ); // "Je ne sais pas"


//--------------------------------------------------------------------------------------------------
//
// Spécialisation de classe template :  un comportement différent selon la nature du type générique
//
//--------------------------------------------------------------------------------------------------

// définition de la classe générique:

template <class T>
class mycontainer {

    T element; //juste un seul membre privé

    public:
    mycontainer (T arg) { element = arg; } // un seul constructeur, et par paramètre

    T increase () {return ++element;} // simple fonction qui va auto-incrémenter l'attribut element
};



// Spécialisation de la classe

template <> // ATTENTION ICI : SYNTAXE particulière avec < > !!!!
class mycontainer <char> {

    char element; // element n'est plus un membre générique!!!

    public:
    mycontainer (char arg) {element=arg;} // constructeur inchangé

    //ajout d'une fonction membre spécifique pour le type char
    char uppercase ()
    {
        if ( element >= 'a' && element <= 'z' )     element+='A'-'a';
        return element;
    }
};




#endif // EXEMPLESPECIALISATIONTEMPLATE_H
