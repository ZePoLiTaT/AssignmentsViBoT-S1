#ifndef FONCTIONSVIRTUELLES_H
#define FONCTIONSVIRTUELLES_H

//--------------------------------
//
//  exemple : un exemple un peu plus concret, et un peu plus propre, d'héritage multiple
//
//--------------------------------


class CPolygon {
    protected: int width, height;
    public:
        void set_values (int a, int b) { width=a; height=b; }
        virtual int area () { return (0); } //si on met cette fonction en virtuelle pure, on ne pourra plus créer d'objet de type CPolygon
};

class CRectangle: public CPolygon {
    public:
    int area () { return (width * height); } //fonction spécifique pour le calcul d'aire d'un rectangle
};

class CTriangle: public CPolygon {
    public:
    int area () { return (width * height / 2); } //fonction spécifique pour le calcul d'aire d'un triangle rectangle
};

void Exemple();



#endif // FONCTIONSVIRTUELLES_H
