#include <QCoreApplication>
#include "FonctionsVirtuelles.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    Exemple ();
    
    return a.exec();
}
