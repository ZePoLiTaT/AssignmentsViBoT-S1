#include <FonctionsVirtuelles.h>
#include <iostream>
using namespace std;

void Exemple()
{
    system ("cls");
    cout <<"\t\t EXEMPLE on cree un polygone, un triangle, et un rectangle"<<endl<<endl;

//allocation statique suivie de récupération d'un pointeur (vers la classe mère!!) pour pouvoir travailler
CRectangle rect; CPolygon * ppoly1 = &rect; ppoly1->set_values (4,5);
CTriangle trgl; CPolygon * ppoly2 = &trgl; ppoly2->set_values (4,5);
CPolygon poly; CPolygon * ppoly3 = &poly; ppoly3->set_values (4,5);

cout <<"ADRESSES DES OBJETS CREES: "<<endl;
cout << "Rect= "<<&rect<<" Trgl= "<<&trgl<< " Poly= "<<&poly<<endl<<endl;
cout <<"VERIF AVEC LES POINTEURS"<<endl;
cout << "Rect= "<<ppoly1<<" Trgl= "<<ppoly2<< " Poly= "<<ppoly3<<endl<<endl;


//Appels syntaxiquement identiques, mais en pratique, le compilateur saura quelle fonction appeler
cout << ppoly1<<"->area()="<<ppoly1->area() << endl; // area() de CRectangle
cout << ppoly2<<"->area()="<<ppoly2->area() << endl; // area() de CTriangle
cout << ppoly3<<"->area()="<<ppoly3->area() << endl; // area() de CPolygon
system("pause");
}

