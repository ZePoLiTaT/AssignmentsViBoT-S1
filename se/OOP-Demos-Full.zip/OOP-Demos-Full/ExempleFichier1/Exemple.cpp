#include "Exemple.h"

#include <fstream>
#include <iostream>
#include <cstring>
using namespace std;

// un premier exemple d'écriture dans un fichier sans spécifier les modes d'accès : ainsi on va simplement écrire du texte

void Exemple1 ()
{
    cout <<"Entrez le nom du fichier qui va etre ouvert en ECRITURE"<<endl;
    string filename;
    cin >> filename;

    //allocation directe du flux sans passer par open et autres...
    ofstream MonFichier(filename.c_str());

    if (!MonFichier.is_open()) {cerr <<"ERREUR: echec de l'ouverture du fichier "<<endl; return;}

    int n;
    cout <<"Combien de lignes voulez vous entrer?"<<endl;
    cin >> n;

    //appel à ignore...pour évacuer le caractère \n créé par l'appui sur la touche entrée
    cin.ignore();

    for (int i = 0; i< n; i++)
    {
        string MaLigneDeTexte;
        cout <<"Entrez votre texte en ligne "<<i<<endl;
        getline (cin,MaLigneDeTexte);
        cout << MaLigneDeTexte<<endl;
        MonFichier << MaLigneDeTexte.c_str() << endl;
    }

    //ne surtout pas oublier de fermer le flux!
    MonFichier.close();

    cout <<"Fichier ferme, on sort"<<endl;
}


// un premier exemple de lecture dans un fichier sans spécifier les modes d'accès : ainsi on va simplement lire du texte

void Exemple2 ()
{
    cout <<"entrez le nom de fichier en lecture..."; string filename; cin>>filename;

    ifstream MonFluxDeLecture (filename.c_str() );

    if (!MonFluxDeLecture.is_open()) {cerr <<"ERREUR ouverture fichier : " <<filename<<endl; return;}

    string MaLigneDeTexte; int n_ligne = 1;

    while(getline(MonFluxDeLecture, MaLigneDeTexte))  // tant que l'on peut mettre la ligne dans "contenu"
            {
        cout << n_ligne++ <<" "<< MaLigneDeTexte << endl;  // on l'affiche
            }
}
