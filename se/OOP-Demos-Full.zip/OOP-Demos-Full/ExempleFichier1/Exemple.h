#ifndef EXEMPLE_H
#define EXEMPLE_H

//deux déclarations de fonctions toutes simples
void Exemple1 ();
void Exemple2 ();


#endif // EXEMPLE_H
