#include <QCoreApplication>

#include "Exemple.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    
    Exemple1();
   // Exemple2();

    return a.exec();
}

