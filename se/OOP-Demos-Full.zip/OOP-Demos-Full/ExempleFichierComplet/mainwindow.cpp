#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QFileDialog> //pour utiliser les boites de dialogues pour se promener sur le disque
#include <cstring>
#include <iostream>
#include <fstream>
using namespace std;

//constructeur : rien de difficile

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this); //comme d'habitude, on initialise l'interface

    //on se place en mode lecture par défaut
    mode = ios :: in;

    //on met à jours la check box correspondant
    ui->checkBox_in->setChecked(true);

    //on appelle notre "décortiqueur" de mode pour vérifier si tout est correct
    FlagAnalysis ();

    //par défaut, on ne peut pas éditer dans le text browser, donc on le spécifie
    ui->textBrowser->setReadOnly(true);
    ui->checkBox->setChecked(true); //mise a jour check box de l'interface graphique

}

//destructeur : rien à signaler ici, tout est alloué statiquement

MainWindow::~MainWindow()
{
    delete ui;
}

//-------------------------------------------------------------------------------------------
//
//fonction appelée lors d'un clic sur le bouton parcourir (ouverture de la boite de dialogue)
//
//-------------------------------------------------------------------------------------------

void MainWindow::on_Button1_clicked()
{
    QFileDialog dialog(this);

    //permettre l'ouverture de la boite pour lire un fichier existant, ou surtout, pour pouvoir créer un fichier (en mode sauvegarde)
    dialog.setFileMode(QFileDialog::AnyFile);

    //pour gerer la selection de plusieurs fichiers:
    //dialog.setFileMode(QFileDialog::ExistingFiles);

    //Exemple de gestion des extensions, même des extensions "maison"
    dialog.setNameFilter(QString("Fichiers (*.txt *.yo *.yohan) ;; All files (*.*)"));


    /*
    The file dialog has two view modes: List and Detail.
    List presents the contents of the current directory as a list of file and directory names.
    Detail also displays a list of file and directory names, but provides additional information alongside each name,
    such as the file size and modification date. Set the mode with setViewMode():
    */

    dialog.setViewMode(QFileDialog::Detail);


    //on peut récupérer potentiellement plusieurs fichiers :
    //on a besoin d'une structure un peu plus complexes qu'une simple QString.
    //En fait, il faut soit un tableau, soit une liste de QString...

    QStringList fileNames;
    if (dialog.exec())
        fileNames = dialog.selectedFiles();

    //initialisation de la liste des fichiers actuellement sélectionnés
    ui->ListFileNames->clear();

    //insertion élément par élément de la liste affichée en utilisant un index (on peut faire beaucoup mieux avec des itérateurs, mais ce n'est pas au programme cette année...)
    for (int i=0; i<fileNames.size(); i++)     ui->ListFileNames->addItem(fileNames[i]);
}

//fonction appelée quand on clique sur un des noms de fichier depuis la liste
void MainWindow::on_ListFileNames_itemClicked(QListWidgetItem *item)
{
    filename = QString( item->text() ).toStdString(); // grosse conversion en string standard
    ui->label_fichieractif->setText(QString(filename.c_str())); // mise à jour d'une étiquette dans l'autre onglet, histoire de toujours savoir sur quel fichier on travaille
}

//----------------------------------------------
//
//fonctions pour basculer les états des drapeaux
//
//----------------------------------------------

void MainWindow::on_checkBox_in_clicked()
{
    mode  ^= ios :: in; //on se place en mode lecture par défaut
    FlagAnalysis ();
}

void MainWindow::on_checkBox_out_clicked()
{
    mode  ^= ios :: out; //on se place en mode lecture par défaut
    FlagAnalysis ();
}

void MainWindow::on_checkBox_binary_clicked()
{
   mode ^= ios::binary;
   FlagAnalysis ();
}

void MainWindow::on_checkBox_trunc_clicked()
{
    mode ^= ios::trunc;
    FlagAnalysis ();
}

void MainWindow::on_checkBox_app_clicked()
{
    mode ^= ios::app;
    FlagAnalysis ();
}

void MainWindow::on_checkBox_ate_clicked()
{
    mode ^= ios::ate;
    FlagAnalysis ();
}

// "décortiqueur de mode"
// fonction qui va appeler une fonction pour chaque mode
// pour déterminer si chaque drapeau est actif ou non
// puis mettre à jour l'interface (les check boxes non actives)

void MainWindow :: FlagAnalysis ()
{
    ui->checkBox_1->setChecked( is_ios_in_active() );
    ui->checkBox_2->setChecked( is_ios_out_active() );

    ui->checkBox_3->setChecked( is_ios_binary_active() );
    ui->checkBox_4->setChecked( is_ios_trunc_active() );

    ui->checkBox_5->setChecked( is_ios_app_active() );
    ui->checkBox_6->setChecked( is_ios_ate_active() );
}


//fonction qui récupère les drapeaux du mode et verifie qu'ils sont cohérents
bool MainWindow :: IsModeValid ()
{
    // il faut d'abord vérifier qu'on effectue, au minimum, soit un acces en lecture, soit en écriture

    bool in, out;

    in = is_ios_in_active();
    out = is_ios_out_active();

    if (!in && !out) {cerr << "Mode indefini : NI en lecture, NI en ecriture..."<<endl; return false;}

    bool app, trunc;
    app = is_ios_app_active();
    trunc = is_ios_trunc_active();

    //on vérifie que tout est bon pour C++98
    if (trunc && app) {cerr << "C++98 error : trunc et app non compatibles "<<endl; return false;}
    if ((trunc || app) && !out) {cerr << "C++98 error : trunc ou app sans out... "<<endl; return false;}
    if (app  && in) {cerr << "C++98 error : app et in compatibles "<<endl; return false;}

    // on re-verifie que tout est bon pour C++11
    if (trunc && app) {cerr << "C++11 error : trunc et app non compatibles "<<endl; return false;} // ligne inutile, mais qui colle à la diapo du cours
    if (trunc  && !out) {cerr << "C++11 error : trunc  sans out... "<<endl; return false;}   // idem, déjà testée avant

    //si on arrive ici, tout est correct, on peut ouvrir avec le mode actif

    return true;
}

// fonction appelée quand on clique sur le bouton : LIRE/ECRIRE les données

void MainWindow::on_pushButton_clicked()
{
    if ( ! IsModeValid() ) {return;} //mode incohérent : on se sauve sans rien faire
    if (filename == "") {cerr <<"Ficher non specifie"<<endl; return;} // pas de chemin : on affiche un message d'erreur et on sort de la fonction

    //ici, les paramètres pour l'ouverture sont validés : donc on peut travailler

    // 1 - déclaration d'un flux
    fstream MonFlux;

    // 2 - ouverture du fichier spécifié avec les modes sélectionnés
    MonFlux.open (filename.c_str(),mode);

    // 3 - vérification de l'ouverture. Si erreur, on se sauve, encore une fois
    if(!MonFlux.is_open()) {cerr <<" Erreur ouverture flot"<<endl; return;}

    // 4 - traitements divers. Ici, on va gérer deux cas : lecture simple et écriture simple

    if (is_ios_in_active() && ! is_ios_out_active() ) //lecture simple
    {
       ui->textBrowser->clear();
       string buffer;
        while (getline (MonFlux, buffer ))
           ui->textBrowser->append( QString(buffer.c_str()));
    }

    if (!is_ios_in_active() && is_ios_out_active() ) //ecriture simple
    {
        MonFlux <<ui->textBrowser->document()->toPlainText().toStdString();

    }

    // 5 - fermeture du flux

    MonFlux.close();
}

void MainWindow::on_checkBox_clicked()
{
    //verrouille l'édition de texte dans le TextBrowser

    ui->textBrowser->setReadOnly( ui->checkBox->isChecked() );
}
