#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QListWidgetItem>
#include <ios>
using namespace std;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    //déclaration d'un membre de type ios_base::openmode pour savoir "comment" on ouvrira les fichiers
    ios_base::openmode mode;
    //déclaration d'un membre string pour mémoriser le chemin du fichier
    string filename;

    //accesseurs pour savoir si certains modes sont actifs
    bool is_ios_in_active() const { return (mode & ios :: in) == ios :: in;}
    bool is_ios_out_active() const { return (mode & ios :: out) == ios :: out;}
    bool is_ios_binary_active() const { return  (mode & ios :: binary) == ios :: binary;}
    bool is_ios_trunc_active() const { return (mode & ios :: trunc) == ios :: trunc;}
    bool is_ios_app_active() const { return  (mode & ios :: app) == ios :: app;}
    bool is_ios_ate_active() const { return  (mode & ios :: ate) == ios :: ate;}
    
private slots:

    //les deux fonctions appelées quand on clique sur les deux boutons
    void on_Button1_clicked();
    void on_pushButton_clicked();

    //fonction appelée quand on clique sur un élément de la liste, une fois plusieurs fichiers sélectionnés
    void on_ListFileNames_itemClicked(QListWidgetItem *item);

    //------------------------------------------------------------------------------------------------------
    //
    //travail avec les masques... Pour en apprendre davantage : http://www.vipan.com/htdocs/bitwisehelp.html
    //
    //------------------------------------------------------------------------------------------------------

    //fonction de mise à jours des drapeaux pour les flux
    void on_checkBox_in_clicked();
    void on_checkBox_out_clicked();
    void on_checkBox_binary_clicked();
    void on_checkBox_trunc_clicked();
    void on_checkBox_app_clicked();
    void on_checkBox_ate_clicked();

    //fonction qui va analyser les drapeaux à partir du mode d'ouverture pour mettre à jour l'interface
    void FlagAnalysis ();
    //fonction qui détermine si un mode d'accès est valide ou non
    bool IsModeValid ();

    //verrouillage et dévérouillage pour modifier le texte dans le texte Browser
    void on_checkBox_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
