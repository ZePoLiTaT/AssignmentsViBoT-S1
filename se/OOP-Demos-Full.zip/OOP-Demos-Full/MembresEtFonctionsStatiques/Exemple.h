#ifndef EXEMPLE_H
#define EXEMPLE_H

class A {

public:

    int i;
    static int j;

    A ( );
    ~A ( );

    static int CombienOnEst ();
};

//dérivation simpliste pour illustrer la transmission directe des fonctions et membres statiques
class B : public A {

public :
    int k;
    B( );
    ~B( );
};

//fonction exemple sur les pointeurs
void FonctionExemplePointeurs ( );


#endif // EXEMPLE_H
