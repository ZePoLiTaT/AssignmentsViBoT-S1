#include "Exemple.h"
#include <iostream>
using namespace std;

//initialisation du membre statique de A

int A :: j = 0;

A :: A ( ){
    i = 0;
    j++;
}

A :: ~A ( )
{
    j--;
}

int A ::  CombienOnEst ( )
{
    return j;
}

//constructeurs et destructeurs qui ne font rien de particulier car tout est alloué statiquement
B :: B () { }
B :: ~B () { }

//fonction pour illustrer la compatibilité entre pointeurs
void FonctionExemplePointeurs ( )
{

    system("cls");
    cout <<"Exemple de compatibilite entre pointeurs de classe parent et classe derivee"<<endl;
    cout <<endl<<endl<<"Creation de deux instances de classe A"<<endl;
    A Objet1, Objet2;
    Objet1.i = 1; Objet2.i = 2;

    //on récupère deux pointeurs
    A* ptrObjet1 = &Objet1, * ptrObjet2 = &Objet2;

    cout <<endl<<endl<<"Creation de deux instances de classe B"<<endl;
    B Objet3, Objet4;
    Objet3.i = 3; Objet4.i = 4;
    Objet3.k = 33; Objet4.k = 44;

    B* ptrObjet3 = &Objet3, * ptrObjet4 = &Objet4;

    cout <<endl<<endl<<"Affichages des membres en passant par les pointeurs"<<endl;
    //déja ici c'est limite
    cout << ptrObjet1->i <<" "<<ptrObjet2->i <<" "<<ptrObjet3->i <<" "<<ptrObjet4->i<< endl;

    //là ça reste encore logique
    cout << ptrObjet3->k <<" "<<ptrObjet4->k<< endl;

    //mais ici, attention :
    //attention ici, on a une instruction de la forme A* = &B

    cout <<endl<<endl<< "on convertit un B* en A* et on regarde ce qui se passe:"<<endl;

    ptrObjet1 = &Objet3;
    //l'instruction suivante passe
    cout <<ptrObjet1->i << endl;
    //l'instruction ne suivante ne passe plus, pourquoi?
    //cout<<ptrObjet1->k<<endl;





}


