#include <QCoreApplication>
#include <iostream>
using namespace std;

#include "Exemple.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //création de bloc d'instructions pour détruire les variables locales
    {
        A a1, a2, a3, a4, a5;
        cout << "On vient de creer " << a1.CombienOnEst() << " objets" << endl;

        A tab[10];
        cout << "Maintenant, nous sommes " << tab[0].CombienOnEst() << " objets" << endl;
    }

    cout <<"Et ici, maintenant, il reste " << A :: CombienOnEst() << " objets" << endl;

    {
        B b1,b2,b3;
        cout << "Maintenant, nous sommes " << b1.CombienOnEst() << " objets" << endl;
    }

    B tab[25]; // on crée 25 instances de la classe B
    cout << "Maintenant, nous sommes " << B :: CombienOnEst() << " objets" << endl;


    FonctionExemplePointeurs ( );

    return a.exec();
}
