#include "CRectangle.h"
#include <cassert> // pour utilisation dans un mutateur
#include <iostream>

using namespace std;

//--------------------------------------
//
//Constructeurs et Destructeurs
//
//--------------------------------------

//constructeur par défaut
CRectangle :: CRectangle ()
{
    longueur = largeur = 0;
    cout <<"appel du CSTR par Defaut"<<endl;
}


//constructeur par paramètre
CRectangle :: CRectangle (int a, int b)
{
    longueur = a;
    largeur = b;
    cout <<"Appel du CSTR par parametre a="<< a << " b=" << b << endl;
}

//constructeur par copie
CRectangle :: CRectangle (const CRectangle &R)
{
    longueur = R.longueur;
    largeur = R.largeur;

    cout <<"Je suis : "<< this << endl <<"Appel du CSTR par copie du rectangle situé en " << &R <<endl;
}

//destructeur
CRectangle :: ~CRectangle ()
{
    //rien à faire car aucune allocation d'attribut dynamique

    cout <<" Je suis l objet" << this << " et je vais disparaaaaaitre..."<<endl;
}

//--------------------------------------
//
//Quelques fonctions simples
//
//--------------------------------------

int CRectangle :: aire () const
{
    return longueur*largeur;
}

void CRectangle ::Affiche() const
{
    cout <<"Rectangle en adresse "<<this<< "\tl = "<<longueur<<" L="<<largeur<<endl<<endl;
}

//--------------------------------------
//
// accesseurs et mutateurs pour chaque membre
//
//--------------------------------------

inline int CRectangle :: Get_longueur ( void ) const { return longueur; }
inline int CRectangle :: Get_largeur ( void ) const { return largeur; }

//--------------------------------------
//
//mutateurs : permettent de vérifier les données avant de modifier
//
//--------------------------------------

//première technique : si on essaie de faire une opération incohérente, on affiche une erreur puis on quitte sans rien faire

void CRectangle :: Set_longueur ( int valeur ) {

    if (valeur <0 ) {cerr <<"ERREUR : Tentative affectation longueur < 0 "<<endl; return;}
    longueur = valeur;
}

//seconde technique : si on essaie de faire une opération incohérente, on affiche une erreur et on termine le programme

void CRectangle :: Set_largeur ( int valeur )
{
    assert (valeur >= 0);
    largeur = valeur;
}


//---------------attention ici-----------------------
// je vous ai un peu "menti" dans le dernier programme
// pour clarifier les histoire de retour vers le pointeur this ou l'adresse de l'objet
// je vous ai refait, clairement, deux fonctions
// MonPointeur renvoie un pointeur vers l'objet
// MonAdresse renvoie la référence (l'adresse) de l'objet
// la référence et le pointeur vers l'objet sont et seront toujours des objets constants
// c'est pourquoi le type de retour est
// const CRectangle *
// ou bien
// const CRectangle &
//
//essayez d'oter const et vous verrez ;)
//

//exemple d'utilisation du pointeur this
const CRectangle* CRectangle ::  MonPointeur (void) const {return this;}

//exemple d'utilisation du pointeur this
const CRectangle& CRectangle ::  MonAdresse (void) const {return *this;}




//--------------------------------------
//
//surcharge des opérateurs
//
//--------------------------------------

// =  va modifier ses données membres tout en effectuant les vérifications nécessaires
// pour pouvoir enchainer les affectations, du type R1 = R2 = R3 = R4,
// on retournera encore une fois l'adresse de l'objet après modification

CRectangle& CRectangle :: operator = (const CRectangle& R)
{
    Set_largeur ( R.Get_largeur() );
    Set_longueur ( R.Get_longueur() );
    return *this;
}


// += va modifier les données membres c'est donc une fonction NON constante
// pour pouvoir "chainer" différents appels, cet opérateur retournera comme résultat une référence vers lui-même (son adresse)
// pour ce faire, il suffira de retourner *this ...

CRectangle& CRectangle :: operator +=(const CRectangle & R)
{
    //on en profite ici pour bannir tout = non vérifié en utilisant les accesseurs et mutateurs
    Set_largeur ( Get_largeur() + R.Get_largeur() );
    Set_longueur( Get_longueur() + R.Get_longueur() );

    //première grosse astuce : on retourne la référence vers l'objet après modification
    //pourquoi pas le pointeur this?
    //parce que tous les autres opérateurs ont besoin d'une référence constante, pas d'un pointeur...

    return *this;
}


// + ne modifie pas les données membre, il crée un nouveau rectangle.
// Donc c'est une fonction constante (d'où le dernier const)
// De plus, le rectangle passé en paramètre n'est pas non plus modifié, d'où le premier const
// enfin, pour éviter des copies locales douteuses, on passe par référence

// Attention - WARNING - DANGER!!
// Deux points importants
// un opérateur membre ne prend qu'un seul paramètre...
// donc pour écrire R = R1 + R2, il faut en fait ecrire R.operator = (R1.operator+(R2)) et que R soit déjà créé...
// Or ici, on va devoir créer un nouvel objet R pour stocker le résultat de l'addition
// Le problème est que comme l'on crée l'objet R localement ET statiquement, il sera automatiquement détruit en fin de fonction (argl!)
// C'est pourquoi on ne retournera pas une référence constante (de type CRectangle &) comme les autres
// mais un résultat de type CRectangle (en fait return <Var locale> va permettre de sauver notre variable de la destruction ;)


CRectangle  CRectangle :: operator + (const CRectangle& R) const
{

    //auto clonage interne ( yes we rock in ge2i \o/ )
    CRectangle Clone (*this); // création variable locale qui sera détruite
    Clone += R; // On calcule la somme qui sera stockée dans la copie

    //auto incrémentation d'un clone local,
    //le return va lui-même repasser en retour de l'appel à l'opérateur + une COPIE des valeurs du clone
    // astuce de programmeur ici : utiliser l'opérateur += pour simplifier le code!!!
    return Clone;


    // pour ceux qui aiment faire court, sans allocation explicite de variable locale : tout en une ligne...
    // attention, difficile à debugger pour un non expert...
    //return CRectangle(*this) += R;
}


ostream& operator <<(ostream &Flux, const CRectangle & R)
{
    Flux <<"Rectangle "<<&R<<"\t lon="<<R.Get_longueur()<<"  lar="<<R.Get_largeur();
    return Flux;
}
