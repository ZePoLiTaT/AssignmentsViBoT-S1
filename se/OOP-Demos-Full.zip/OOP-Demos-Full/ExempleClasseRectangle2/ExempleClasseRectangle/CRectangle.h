#ifndef CRECTANGLE_H
#define CRECTANGLE_H


class CRectangle{

    private:
    int longueur, largeur;

    public:
    CRectangle (); //constructeur par défaut
    CRectangle (int, int ) ; //constructeur par paramètre
    CRectangle (const CRectangle &); //constructeur par copie
    ~CRectangle (); //destructeur


    int aire () const;
    void Affiche() const;
    const CRectangle * MonPointeur (void) const;
    const CRectangle& MonAdresse (void) const;

    // accesseurs et mutateurs pour chaque membre
    inline int Get_longueur ( void ) const;
    inline int Get_largeur ( void ) const;
    void Set_longueur ( int );
    void Set_largeur ( int );

    //surcharge des opérateurs avec un seul paramètre :  dans la classe

     CRectangle& operator += (const CRectangle & );
     CRectangle& operator = (const CRectangle&) ;
     CRectangle operator+ (const CRectangle&) const;

};

//on évite les inclusions de namespaces dans les .h
// donc on va spécifier std :: ostream dans l'en-tête

#include <ostream>
std :: ostream& operator<< (std :: ostream &, const CRectangle &);


#endif // CRECTANGLE_H
