#include <QCoreApplication>
#include "CRectangle.h"
#include <iostream>

using namespace std;

// constructeurs et destructeurs

void Test (void)
{
    CRectangle R1;
    cout <<"Objet "<<R1.MonPointeur()<<endl;
    R1.Affiche();
    system("pause");

    CRectangle *pR1 = new CRectangle;
    cout <<"Objet "<<pR1->MonPointeur()<<endl;
    pR1->Affiche();
    system("pause");

    CRectangle R2(4,6);
    cout <<"Objet "<<R2.MonPointeur()<<endl;
    R2.Affiche();
    system("pause");

    CRectangle *pR2 = new CRectangle(1,9);
    cout <<"Objet "<<pR2->MonPointeur()<<endl;
    pR2->Affiche();
    system("pause");

    CRectangle R3 ( R1 );
    cout <<"Objet "<<R3.MonPointeur()<<endl;
    R3.Affiche();
    system("pause");

    CRectangle *pR3 = new CRectangle( R2);
    cout <<"Objet "<<pR3->MonPointeur()<<endl;
    pR3->Affiche();
    system("pause");

    cout <<"Appel du destructeur via delete"<<endl;
    delete pR1; delete pR2; delete pR3;
    cout << "fin de fonction test, la pile doit libérer les objets alloués statiquement"<<endl;
}

//accesseurs et mutateurs

void Test2 ( void )
{
    //on tente d'affecter des valeurs incohérentes via les mutateurs

    CRectangle UnRectangle (2, 6);

    cout <<endl<<"premiere tentative..."<<endl;
    UnRectangle.Set_longueur (-3);

    cout <<endl<<"seconde tentative..."<<endl;
    UnRectangle.Set_largeur (-3);
}

//opérateurs arithmétique

void Test3 ( void )
{
    CRectangle R1(1,1), R2(2,4);

    R1.Affiche();
    R2.Affiche();

    //d'abord on teste +=
    R1 += R2;

    cout <<"R1 apres operateur +=" << endl;
    R1.Affiche();

    R1 = R2;

    cout <<"R1 apres operateur =" << endl;
    R1.Affiche();

    CRectangle R3 = R1 + R2;
    cout <<"R3 : Creation, ajout et copie... "<<endl;
    R3.Affiche();

    CRectangle R4;

    R4 = R3 = R2 = R1;

    cout <<endl<<" Grosse affectation en chaine"<<endl;
    R1.Affiche();
    R2.Affiche();
    R3.Affiche();
    R4.Affiche();

    cout <<endl<<" Grosse addition en chaine"<<endl;
    R4 = R1 + R2 + R3;

    R4.Affiche();
}

//redefinition de l'opérateur <<

void Test4()
{
    CRectangle R1(4,5), R2(6,1), R3( R1 + R2 );

    //si on a bien redéfinit l'opérateur << pour travailler avec ostream et CRectangle, on peut écrire les lignes suivantes
    //sinon, le compilateur indique une erreur

    cout << R1 << endl << R2 << endl << R3 << endl;

    //en utilisant les opérateurs précédents

    cout << "R1 + R3 ="<< R1 + R3 <<endl;
}


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    Test4 ();

    return a.exec();
}


