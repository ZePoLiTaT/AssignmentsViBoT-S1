#include <QCoreApplication>
#include "CRectangle.h"
#include <iostream>
using namespace std;

void Test (void)
{
    CRectangle R1;
    cout <<"Objet "<<R1.MonAdresse()<<endl;
    R1.Affiche();
    system("pause");

    CRectangle *pR1 = new CRectangle;
    cout <<"Objet "<<pR1->MonAdresse()<<endl;
    pR1->Affiche();
    system("pause");

    CRectangle R2(4,6);
    cout <<"Objet "<<R2.MonAdresse()<<endl;
    R2.Affiche();
    system("pause");

    CRectangle *pR2 = new CRectangle(1,9);
    cout <<"Objet "<<pR2->MonAdresse()<<endl;
    pR2->Affiche();
    system("pause");

    CRectangle R3 ( R1 );
    cout <<"Objet "<<R3.MonAdresse()<<endl;
    R3.Affiche();
    system("pause");

    CRectangle *pR3 = new CRectangle( R2);
    cout <<"Objet "<<pR3->MonAdresse()<<endl;
    pR3->Affiche();
    system("pause");

    cout <<"Appel du destructeur via delete"<<endl;
    delete pR1; delete pR2; delete pR3;
    cout << "fin de fonction test, la pile doit libérer les objets alloués statiquement"<<endl;
}


int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    Test();

    cout <<"on est sorti de la fonction"<<endl;
    
    return a.exec();
}
