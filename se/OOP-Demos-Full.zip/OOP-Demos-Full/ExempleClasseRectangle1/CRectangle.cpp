#include "CRectangle.h"

#include <iostream>
using namespace std;


//constructeur par défaut
CRectangle :: CRectangle ()
{
    longueur = largeur = 0;
    cout <<"appel du CSTR par Defaut"<<endl;
}


//constructeur par paramètre
CRectangle :: CRectangle (int a, int b)
{
    longueur = a;
    largeur = b;
    cout <<"Appel du CSTR par parametre a="<< a << " b=" << b << endl;
}

//constructeur par copie
CRectangle :: CRectangle (const CRectangle &R)
{
    longueur = R.longueur;
    largeur = R.largeur;

    cout <<"appel du CSTR par copie du rectangle situé en " << &R <<endl;
}

//destructeur
CRectangle :: ~CRectangle ()
{
    //rien à faire car aucune allocation d'attribut dynamique

    cout <<" Je suis l objet" << this << " et je vais disparaaaaaitre..."<<endl;
}

int CRectangle :: aire (){return longueur*largeur;}
void CRectangle ::Affiche() {cout <<"Rectangle en adresse "<<this<< "\tl = "<<longueur<<" L="<<largeur<<endl<<endl;}

//exemple d'utilisation du pointeur this
CRectangle* CRectangle ::  MonAdresse (void) {return this;}
