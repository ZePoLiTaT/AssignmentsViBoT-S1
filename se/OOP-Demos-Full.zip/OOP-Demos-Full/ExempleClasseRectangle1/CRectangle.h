#ifndef CRECTANGLE_H
#define CRECTANGLE_H


class CRectangle{

    private:
    int longueur, largeur;

    public:
    CRectangle (); //constructeur par défaut
    CRectangle (int, int ) ; //constructeur par paramètre
    CRectangle (const CRectangle &); //constructeur par copie
    ~CRectangle (); //destructeur


    int aire ();
    void Affiche();
    CRectangle * MonAdresse (void);

};

#endif // CRECTANGLE_H
