#include "Personne.h"
#include <cassert>
#include <iostream>
using namespace std;

Personne :: Personne ()
{
    nom =  "Non defini";
    prenom =  "Non defini";

    attribut_test_public  = 100;
    attribut_test_protected = 2000;
    attribut_test_private = 30000;
}

Personne :: Personne (const string& n, const string& p)
{

    set_nom ( n );
    set_prenom( p );

    attribut_test_public  = 100;
    attribut_test_protected = 2000;
    attribut_test_private = 30000;

}

Personne :: Personne ( const Personne & P)
{
    set_nom ( P.get_nom());
    set_prenom( P.get_prenom() );
    attribut_test_public  = 100;
    attribut_test_protected = 2000;
    attribut_test_private = 30000;
}

string Personne :: get_nom() const { return nom; }
string Personne :: get_prenom() const { return  prenom; }

void Personne :: set_nom (const string & s)
{
    assert ( !s.empty() ); // on verifie que la chaine n'est pas vide
    nom = s;
}

void Personne :: set_prenom (const string &s)
{
    assert ( !s.empty() ); // on verifie que la chaine n'est pas vide
    prenom = s;
}

//surcharge operateur de décalage

ostream & operator << (ostream & o, const Personne &P) {
    o << P.get_nom() << " "
      << P.get_prenom() <<" "
      << P.attribut_test_public<<"/"
      << P.attribut_test_protected<<"/"
      << P.attribut_test_private;

    return o;
}

//-------------------------------
//
// class Professeur
//
//-------------------------------


Professeur :: Professeur () : Personne ()
{
    nombre_matiere = 0;
    enseignements =  NULL;
}

Professeur :: Professeur (int n ) : Personne ()
{
    nombre_matiere = n;
    enseignements = new string[n];
    for (int i=0; i<n; ) enseignements[i] = "non defini";

}

Professeur :: Professeur (const string& n, const string& p) : Personne ( n, p)
{
    nombre_matiere = 0;
    enseignements =  NULL;
}

Professeur :: Professeur (const string&n, const string&p, int nb) : Personne ( n, p)
{
    nombre_matiere = nb;
    enseignements = new string[nb];
    for (int i=0; i<nb;i++ ) enseignements[i] = "non defini";
}

ostream & operator << (ostream & o, const Professeur &P) {
    o << P.get_nom() << " " << P.get_prenom() <<endl;

    for (int i =0; i<P.get_n();i++) cout <<P.get_matiere(i)<<endl;

    return o;
}


//fonction pour tester une tentative d'accès à tous les membres en fonction du type d'héritage
//otez les commentaires et testez...


void Professeur :: TentativeAcces()
{
//    cout << attribut_test_public <<endl;
//    cout << attribut_test_protected <<endl;
//    cout << attribut_test_private <<endl;
}



