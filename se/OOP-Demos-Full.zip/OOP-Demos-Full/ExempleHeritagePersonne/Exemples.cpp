#include "Exemples.h"

void FonctionExemple( )
{
    //allocation statique de deux variables de type X avec appel cstr par defaut et paramètres
    std :: cout << "X maVar1; "<<std::endl;
    X maVar1;
    std::cout << std::endl;

    std :: cout << "X maVar2(3,4); "<<std::endl;
    X maVar2(3,4);
    std::cout << std::endl;

    //allocation statique de deux variables de type Y avec appel cstr par defaut et paramètres
    std :: cout << "Y mavar3; "<<std::endl;
    Y mavar3;
    std::cout << std::endl;

    std :: cout << "Y maVar4(5,6,7); "<<std::endl;
    Y maVar4(5,6,7);
    std::cout << std::endl;

    std :: cout <<"la procedure est terminee, on libere les objets"<<std::endl;

    //ici les variables vont être libérées... Quels sont les destructeurs appelés??
}

