#ifndef EXEMPLES_H
#define EXEMPLES_H

#include <iostream>

class X {
public :
    int a, b;
    //cstr par défaut
    X ( ) { a=0; b=0; std::cout << this << " CSTR par DEFAUT de classe de BASE"<<std ::endl; }
    //cstr par paramètre
    X (int i, int j ) { a=i; b=j; std::cout << this << " CSTR par PARAM de classe de BASE "<<i<<" "<<j<<std ::endl; }
    ~X () {std::cout << this << " DSTR de classe de BASE"<<std ::endl; }

};

class Y : public X {
public :
    int c;
     //cstr par défaut
    Y () : X(), c(0) {  std::cout << this << " CSTR par DEFAUT de classe ENFANT"<<std ::endl; }
     //cstr par paramètre
    Y (int aa, int bb, int cc = 0) : X(aa,bb), c(cc) { std::cout << this << " CSTR par PARAM de classe ENFANT "<<aa<<" "<<bb<<" "<<cc<<std ::endl; }
    ~Y () {std::cout << this << " DSTR de classe ENFANT"<<std ::endl; }
};

void FonctionExemple( );

#endif // EXEMPLES_H
