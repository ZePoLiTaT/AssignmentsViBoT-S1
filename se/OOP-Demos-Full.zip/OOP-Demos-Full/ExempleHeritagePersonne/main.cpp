#include <QCoreApplication>
#include "Personne.h"
#include "Exemples.h"
#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    //création statique et affichage d'une personne via CSTR DEFAUT
    Personne P0;
    cout <<P0<<endl;

    //exemple de création d'une objet de type Personne et affichage via opérateur "<<" surchargé
    Personne P1("Jean", "Dupont");
    cout <<P1<<endl;

    //même principe mais pour un objet de type Professeur qui dérive de la classe Personne
    Professeur P2("Yohan", "Fougerolle",3);
    cout << endl << "avant modif ..." << endl << P2 << endl;

    //exemple d'utilisation des accesseurs pour modifier les matières de P2
    cout << endl << "apres modifs"<<endl<<endl;

    P2.set_matiere("Info Indus", 0);
    P2.set_matiere("TP reseaux", 1);
    P2.set_matiere("Projet tuto", 2);

    cout << P2 <<endl;

    //ne pas oublier d'oter les commentaires dans la fonction TentativeAcces
    // illustration du tableau en diapo 18 dans le cours (changez le type d'héritage)
    P2.TentativeAcces();

    //Illustration de l'ordre d'appel des constructeurs/destructeurs pour des classes dérivées
    FonctionExemple();
    
    return a.exec();
}
