#ifndef PERSONNE_H
#define PERSONNE_H

#include <string>
#include <ostream>
#include <istream>
#include <cassert>

using namespace std;

class Personne {

//déclaration des trois membres "bidons" pour illustrer ce qui se passe en héritage
private:
    int attribut_test_private;
protected :
    int attribut_test_protected;
public :
    int attribut_test_public;

// attributs et méthodes "normaux"

protected :
    string nom, prenom;

public :
    Personne ();
    Personne (const string&, const string&);
    Personne ( const Personne &);
    ~Personne () {}

    string get_nom() const;
    string get_prenom() const;
    void set_nom (const string &);
    void set_prenom (const string &);

    friend ostream & operator << (ostream & o, const Personne &P); // truande légère pour afficher l'attribut private en dehors de la classe via <<
};

//surcharge pour afficher avec cout et lire avec cin

ostream & operator << (ostream & , const Personne &);

//-------------------------------
//
// class Professeur
//
//-------------------------------

class Professeur : public Personne
{
protected :
    string * enseignements;
    int nombre_matiere;
public :
    Professeur ();
    Professeur (const string&, const string&);
    Professeur (int);
    Professeur (const string&, const string&, int);
    ~Professeur () {if (enseignements) delete[] enseignements;}

    string get_matiere (const int& i) const {assert (i<get_n()); return enseignements[i];}
    void set_matiere (const string & m, const int i) {assert (i<get_n() && i>=0); enseignements[i] = m;}
    int get_n() const {return nombre_matiere;}
    void TentativeAcces();
};

ostream & operator << (ostream & , const Professeur &);

/*
class Etudiant : public Personne
{
// a vous de jouer
};
*/

#endif // PERSONNE_H
