/***************************************************************************
 *
 *   Creation Date: 11/2/2013
 *   Author:        ZePoLiTaT
 *   File:          monoarray.h
 *   Class:
 *
 *   Modifications:
 *      11/2/2013 - Creation
 *
 ***************************************************************************/

#ifndef MONOARRAY_H
#define MONOARRAY_H

#define NSIZE 10

void arraysExample();

#endif // MONOARRAY_H
