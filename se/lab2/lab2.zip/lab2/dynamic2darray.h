/***************************************************************************
 *
 *   Creation Date: 10/24/2013
 *   Author:        ZePoLiTaT
 *   File:          dynamic2darray.h
 *   Class:
 *
 *   Modifications:
 *      10/24/2013 - Creation
 *
 ***************************************************************************/

#ifndef DYNAMIC2DARRAY_H
#define DYNAMIC2DARRAY_H

void pascalTriangleDynamic(unsigned const int &);

#endif // DYNAMIC2DARRAY_H
